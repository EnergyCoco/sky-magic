# Upgrade Container

![Can haz upgrade.](oredict:oc:upgradeContainer1)

升级箱为[机器人](../block/robot.md)提供额外的升级槽位. 其升级幅度由升级箱规格而定，会双倍增加机器人的复杂度
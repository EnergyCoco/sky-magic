# Terminal Server

![Remote Viewing](oredict:oc:terminalServer)

向外界提供虚拟屏幕和键盘，可以通过绑定终端来控制机器，必须安装在机架里面。

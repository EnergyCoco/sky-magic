# Sign I/O

![I see the signs on the wall.](oredict:oc:signUpgrade)

允许设备和告示牌交互. 可以读取牌子的信息，改变牌子的信息. 
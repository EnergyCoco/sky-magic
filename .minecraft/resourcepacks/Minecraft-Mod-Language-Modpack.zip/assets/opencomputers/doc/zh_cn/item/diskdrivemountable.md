# 可挂载的磁盘

![Snuggly](oredict:oc:diskDriveMountable)

大体相当于[软盘驱动器](../block/diskDrive.md),只是被安装到 [机架](../block/rack.md).

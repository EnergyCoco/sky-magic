# 因特网卡

![Cat videos in 3, 2, ...](oredict:oc:internetCard)

使得 [电脑](../general/computer.md) 能够向因特网发送请求，包括Http和tcp客户端套接字。

安装因特网卡会向电脑安装一批网络应用, 比如pastebin命令，通过神秘代码安装网上大神的软件，或者是wget，下载特定URL的文件。
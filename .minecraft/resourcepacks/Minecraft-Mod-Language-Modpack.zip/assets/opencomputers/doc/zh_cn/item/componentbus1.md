# 组件总线

![I need mooooore.](oredict:oc:componentBus1)

组件总线是[服务器](server1.md)专用的升级， 允许服务器[server](server1.md) 和更多的组件同时通讯, 而不是当机. 像CPU一样有级别，高级总线可以允许服务器通讯更多的组件 

总线通讯限制如下
- T1: 8 
- T2: 12 
- T3: 16 

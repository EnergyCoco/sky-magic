# Trading Upgrade

![Equivalent Exchange](oredict:oc:tradingUpgrade)

交易升级允许自动和商人交易,可以被放在[机器人](../block/robot.md)和[无人机](drone.md)里面，能够探测附近商人的存在，知道自己可以卖什么并完成交易。

# Tank Upgrade

![Suck it.](oredict:oc:tankUpgrade)

储罐升级允许设备存储液体. 每个升级仅能存储一个类型的物品, 提供16桶容量(16000mB). [机器人](../block/robot.md) 和 [无人机](drone.md) 可以从世界中和其他储罐汲取液体, 也可以放回世界或者储罐. 单个设备的储罐数没有限制.

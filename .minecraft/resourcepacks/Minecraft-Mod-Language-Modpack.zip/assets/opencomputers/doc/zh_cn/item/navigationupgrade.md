# Navigation Upgrade

![I'm lost. Again.](oredict:oc:navigationUpgrade)

导航升级返回机器的位置和朝向. 坐标是相对用于合成这个升级的地图的中心而言的, 他的作用范围也限制在哪块地图的大小上面.

内部地图可以通过重新合成来更新，旧地图返还.

推荐与 [路径点](../block/waypoint.md)配合食用.
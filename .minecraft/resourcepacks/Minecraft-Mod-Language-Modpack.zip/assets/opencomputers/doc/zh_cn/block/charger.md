# 充电机

![All right, let's do this.](oredict:oc:charger)

充电机为移动的设备 [机器人](robot.md), [无人机](../item/drone.md) and [平板](../item/tablet.md)充能. 可以被红石激活。

充能速度被红石信号强度决定, 15强度最大.

这个逻辑可以被[扳手](../item/wrench.md)反转。

当一个[平板](../item/tablet.md) 放入充电机后, 第一硬盘[hard drive](../item/hdd1.md) 也会被连接充电机的 [电脑](../general/computer.md)访问到

就像[软盘](../item/floppy.md)一样. 这允许在电脑和平板间传送数据。
